// HashTable.java
// Kevin Liu
// Testing for HashTable

public class HashTable {
    public static void main(String[] args) {
        // String name = "Kevin";
        // System.out.println(name.hashCode());

        // HTable<String> names = new HTable<String>();
        // int kevin = "Kevin".hashCode();
        // names.add("Kevin");
        // names.add("Athavan");
        // names.add("Albert");
        // names.add("a");
        // names.add("b");
        // names.add("c");
        // names.add("d");
        // names.add("e");
        // names.add("f");
        // names.add("g");
        // names.add("h");
        // names.add("i");
        // names.add("j");
        // names.add("k");
        // names.add("l");
        // names.add("m");
        // names.remove("d");

        // System.out.println(names);
        // System.out.println(names.get(kevin));
        // System.out.println(names.toArray());

    }
}
