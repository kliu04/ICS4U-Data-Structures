// BNode.java
// Kevin Liu
// Each node in the binary tree

public class BNode {
    public BNode left;
    public BNode right;
    public int value;

    public BNode(int n) {
        value = n;
    }
}
